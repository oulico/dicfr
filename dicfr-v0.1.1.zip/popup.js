// src/popup/index.ts
var listEl = document.getElementById("word-list");
var countEl = document.getElementById("count");
var emptyEl = document.getElementById("empty");
var statsEl = document.getElementById("stats");
var searchInput = document.getElementById("search-input");
var searchResult = document.getElementById("search-result");
var exportBtn = document.getElementById("export-btn");
var importBtn = document.getElementById("import-btn");
var importFile = document.getElementById("import-file");
var importStatus = document.getElementById("import-status");
var dlSection = document.getElementById("download-section");
var dlBtn = document.getElementById("dl-btn");
var dlProgress = document.getElementById("dl-progress");
var dlBar = document.getElementById("dl-bar");
var dlStatusEl = document.getElementById("dl-status");
var dlErrorEl = document.getElementById("dl-error");
var syncLoginBtn = document.getElementById("sync-login-btn");
var syncBtn = document.getElementById("sync-btn");
var syncLogoutBtn = document.getElementById("sync-logout-btn");
var syncEmail = document.getElementById("sync-email");
var syncMsg = document.getElementById("sync-msg");
var SEED_THRESHOLD = 200;
var pollTimer = null;
var searchStack = [];
async function loadHistory() {
  const [historyRes, statsRes] = await Promise.all([
    chrome.runtime.sendMessage({ type: "GET_HISTORY" }),
    chrome.runtime.sendMessage({ type: "GET_STATS" })
  ]);
  const items = historyRes.items || [];
  const dictSize = statsRes.dictSize || 0;
  if (statsRes.dbReady) {
    statsEl.textContent = `${dictSize.toLocaleString()} words in dictionary`;
  } else {
    statsEl.textContent = "Dictionary not loaded";
  }
  if (dictSize < SEED_THRESHOLD) {
    dlSection.classList.add("visible");
  } else {
    dlSection.classList.remove("visible");
  }
  countEl.textContent = `${items.length} looked up`;
  if (items.length === 0) {
    emptyEl.style.display = "block";
    listEl.innerHTML = "";
    return;
  }
  emptyEl.style.display = "none";
  listEl.innerHTML = "";
  for (const item of items) {
    const row = document.createElement("div");
    row.className = "word-item";
    const wordEl = document.createElement("a");
    wordEl.className = "word sr-link";
    wordEl.textContent = item.word;
    wordEl.dataset.word = item.word;
    wordEl.addEventListener("click", () => {
      searchInput.value = item.word;
      searchWord(item.word);
    });
    const defEl = document.createElement("span");
    defEl.className = "definition";
    defEl.textContent = item.definition;
    const metaEl = document.createElement("div");
    metaEl.className = "meta";
    const timeEl = document.createElement("span");
    timeEl.className = "time";
    timeEl.textContent = formatTime(item.lastLookedUpAt);
    const countBadge = document.createElement("span");
    countBadge.className = "lookup-count";
    countBadge.textContent = `${item.lookupCount}\xD7`;
    const deleteBtn = document.createElement("button");
    deleteBtn.className = "delete-btn";
    deleteBtn.type = "button";
    deleteBtn.textContent = "\xD7";
    deleteBtn.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "DELETE_HISTORY", id: item.id });
      loadHistory();
    });
    metaEl.appendChild(timeEl);
    metaEl.appendChild(countBadge);
    row.appendChild(wordEl);
    row.appendChild(defEl);
    row.appendChild(metaEl);
    row.appendChild(deleteBtn);
    listEl.appendChild(row);
  }
}
var searchTimer = null;
searchInput.addEventListener("input", () => {
  if (searchTimer) clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    const q = searchInput.value.trim();
    if (q.length >= 2) {
      searchWord(q);
    } else {
      hideSearch();
    }
  }, 200);
});
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    searchInput.value = "";
    hideSearch();
  }
});
function hideSearch() {
  searchResult.classList.remove("visible");
  searchResult.innerHTML = "";
  searchStack.length = 0;
}
async function searchWord(word) {
  const res = await chrome.runtime.sendMessage({ type: "LOOKUP", word });
  searchResult.classList.add("visible");
  searchResult.innerHTML = "";
  if (!res.found || !res.word) {
    const similarRes = await chrome.runtime.sendMessage({ type: "GET_SIMILAR", word });
    const similar = similarRes.words || [];
    if (similar.length > 0) {
      renderNotFound(word, similar);
    } else {
      searchResult.innerHTML = `<span class="sr-not-found">No results for "${word}"</span>`;
    }
    return;
  }
  searchStack.push(word);
  renderWord(res.word);
}
function renderWord(w) {
  searchResult.innerHTML = "";
  const header = document.createElement("div");
  header.className = "sr-header";
  if (searchStack.length > 1) {
    const back = document.createElement("button");
    back.type = "button";
    back.className = "sr-back";
    back.textContent = "\u2190";
    back.addEventListener("click", () => {
      searchStack.pop();
      const prev = searchStack[searchStack.length - 1];
      searchStack.pop();
      searchInput.value = prev;
      searchWord(prev);
    });
    header.appendChild(back);
  }
  const wordEl = document.createElement("span");
  wordEl.className = "sr-word";
  wordEl.textContent = w.word;
  header.appendChild(wordEl);
  if (w.pos || w.gender) {
    const posEl = document.createElement("span");
    posEl.className = "sr-pos";
    posEl.textContent = `(${[w.pos, w.gender].filter(Boolean).join(", ")})`;
    header.appendChild(posEl);
  }
  searchResult.appendChild(header);
  if (w.definitions.length > 0) {
    const defsEl = document.createElement("div");
    defsEl.className = "sr-defs";
    for (const d of w.definitions.slice(0, 5)) {
      const defEl = document.createElement("div");
      defEl.className = "sr-def";
      const text = d.translation || d.definition;
      defEl.innerHTML = `\u2022 ${makeClickable(text)}`;
      defsEl.appendChild(defEl);
    }
    searchResult.appendChild(defsEl);
  }
  if (w.examples.length > 0) {
    const ex = w.examples[0];
    if (ex.example) {
      const exEl = document.createElement("div");
      exEl.className = "sr-example";
      exEl.textContent = `"${ex.example}"`;
      if (ex.translation) {
        exEl.textContent += ` \u2014 ${ex.translation}`;
      }
      searchResult.appendChild(exEl);
    }
  }
  chrome.runtime.sendMessage({ type: "GET_SIMILAR", word: w.word }).then((res) => {
    const similar = (res.words || []).filter(
      (s) => s.word !== w.word
    );
    if (similar.length > 0) {
      renderSimilar(similar);
    }
  });
}
function makeClickable(text) {
  return text.replace(/[a-zA-ZÀ-ÿ'-]{2,}/g, (match) => {
    return `<a class="sr-link" data-word="${match}">${match}</a>`;
  });
}
function renderNotFound(word, similar) {
  searchResult.innerHTML = `<span class="sr-not-found">"${word}" not found</span>`;
  if (similar.length > 0) {
    renderSimilar(similar);
  }
}
function renderSimilar(similar) {
  const container = document.createElement("div");
  container.className = "sr-similar";
  const label = document.createElement("div");
  label.className = "sr-similar-label";
  label.textContent = "Similar words";
  container.appendChild(label);
  const wordsEl = document.createElement("div");
  wordsEl.className = "sr-similar-words";
  for (const s of similar.slice(0, 8)) {
    const link = document.createElement("a");
    link.className = "sr-link";
    link.dataset.word = s.word;
    link.textContent = s.word;
    wordsEl.appendChild(link);
  }
  container.appendChild(wordsEl);
  searchResult.appendChild(container);
}
searchResult.addEventListener("click", (e) => {
  const target = e.target;
  if (target.classList.contains("sr-link") && target.dataset.word) {
    searchInput.value = target.dataset.word;
    searchWord(target.dataset.word);
  }
});
function formatTime(ts) {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 6e4);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
function updateDownloadUI(state) {
  dlErrorEl.textContent = "";
  switch (state.status) {
    case "downloading":
      dlBtn.disabled = true;
      dlBtn.textContent = "Downloading...";
      dlProgress.classList.add("visible");
      if (state.progress > 0) {
        dlBar.style.width = `${state.progress}%`;
        dlStatusEl.textContent = `${state.progress}% \u2014 ${formatBytes(state.bytesLoaded || 0)}`;
      } else {
        dlBar.style.width = "0%";
        dlStatusEl.textContent = `${formatBytes(state.bytesLoaded || 0)} downloaded`;
      }
      break;
    case "processing":
      dlBtn.disabled = true;
      dlBtn.textContent = "Loading...";
      dlBar.style.width = "100%";
      dlStatusEl.textContent = "Loading into SQLite...";
      break;
    case "complete":
      dlBtn.disabled = false;
      dlBtn.textContent = "Done!";
      dlProgress.classList.remove("visible");
      stopPolling();
      loadHistory();
      break;
    case "error":
      dlBtn.disabled = false;
      dlBtn.textContent = "Retry";
      dlProgress.classList.remove("visible");
      dlErrorEl.textContent = state.error || "Download failed";
      stopPolling();
      break;
    default:
      dlBtn.disabled = false;
      dlBtn.textContent = "Download Dictionary";
      dlProgress.classList.remove("visible");
  }
}
function startPolling() {
  stopPolling();
  pollTimer = setInterval(async () => {
    const state = await chrome.runtime.sendMessage({
      type: "GET_DOWNLOAD_STATUS"
    });
    updateDownloadUI(state);
  }, 500);
}
function stopPolling() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}
dlBtn.addEventListener("click", async () => {
  dlErrorEl.textContent = "";
  dlBtn.disabled = true;
  await chrome.runtime.sendMessage({ type: "START_DOWNLOAD" });
  startPolling();
});
async function checkOngoingDownload() {
  const state = await chrome.runtime.sendMessage({
    type: "GET_DOWNLOAD_STATUS"
  });
  if (state.status === "downloading" || state.status === "processing") {
    dlSection.classList.add("visible");
    updateDownloadUI(state);
    startPolling();
  }
}
exportBtn.addEventListener("click", async () => {
  const data = await chrome.runtime.sendMessage({ type: "EXPORT_HISTORY" });
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const date = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const a = document.createElement("a");
  a.href = url;
  a.download = `dicfr-export-${date}.json`;
  a.click();
  URL.revokeObjectURL(url);
});
importBtn.addEventListener("click", () => {
  importFile.click();
});
importFile.addEventListener("change", async () => {
  const file = importFile.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (data.version !== 1 || !Array.isArray(data.words)) {
      throw new Error("Invalid file format");
    }
    const result = await chrome.runtime.sendMessage({ type: "IMPORT_HISTORY", data });
    importStatus.textContent = `Imported: ${result.merged} merged, ${result.added} added`;
    importStatus.style.display = "block";
    setTimeout(() => {
      importStatus.style.display = "none";
    }, 3e3);
    loadHistory();
  } catch (err) {
    importStatus.textContent = `Import failed: ${err instanceof Error ? err.message : "unknown error"}`;
    importStatus.style.color = "#c44";
    importStatus.style.display = "block";
    setTimeout(() => {
      importStatus.style.display = "none";
      importStatus.style.color = "#4a9";
    }, 3e3);
  }
  importFile.value = "";
});
function showSyncMsg(text, isError = false) {
  syncMsg.textContent = text;
  syncMsg.style.color = isError ? "#c44" : "#4a9";
  syncMsg.style.display = "block";
  setTimeout(() => {
    syncMsg.style.display = "none";
  }, 3e3);
}
function updateSyncUI(status) {
  if (status.loggedIn && status.email) {
    syncLoginBtn.style.display = "none";
    syncEmail.textContent = status.email;
    syncBtn.style.display = "";
    syncLogoutBtn.style.display = "";
  } else {
    syncLoginBtn.style.display = "";
    syncEmail.textContent = "";
    syncBtn.style.display = "none";
    syncLogoutBtn.style.display = "none";
  }
}
syncLoginBtn.addEventListener("click", async () => {
  syncLoginBtn.disabled = true;
  try {
    const status = await chrome.runtime.sendMessage({ type: "SYNC_LOGIN" });
    updateSyncUI(status);
    showSyncMsg(`Signed in as ${status.email}`);
  } catch (err) {
    showSyncMsg(err instanceof Error ? err.message : "Sign in failed", true);
  }
  syncLoginBtn.disabled = false;
});
syncBtn.addEventListener("click", async () => {
  syncBtn.disabled = true;
  syncBtn.textContent = "Syncing...";
  try {
    const pushResult = await chrome.runtime.sendMessage({ type: "SYNC_PUSH" });
    const pullResult = await chrome.runtime.sendMessage({ type: "SYNC_PULL" });
    showSyncMsg(`Synced: ${pushResult.synced} pushed, ${pullResult.merged + pullResult.added} pulled`);
    loadHistory();
  } catch (err) {
    showSyncMsg(err instanceof Error ? err.message : "Sync failed", true);
  }
  syncBtn.textContent = "Sync";
  syncBtn.disabled = false;
});
syncLogoutBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "SYNC_LOGOUT" });
  updateSyncUI({ loggedIn: false });
  showSyncMsg("Signed out");
});
async function initSyncUI() {
  const status = await chrome.runtime.sendMessage({ type: "GET_SYNC_STATUS" });
  updateSyncUI(status);
}
loadHistory();
checkOngoingDownload();
initSyncUI();
//# sourceMappingURL=popup.js.map
